function generatecat(){
  var image=document.createElement('img')
  var div=document.getElementById('cat-gen-id')
  image.src="https://cdn.pixabay.com/photo/2016/09/05/21/37/cat-1647775_960_720.jpg"
  div.appendChild(image);
}